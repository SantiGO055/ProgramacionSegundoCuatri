﻿namespace MiApp
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNombre = new System.Windows.Forms.TextBox();
            this.brnApellido = new System.Windows.Forms.TextBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.chkContraseña = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.froFemenino = new System.Windows.Forms.RadioButton();
            this.froMasculino = new System.Windows.Forms.RadioButton();
            this.frbOtros = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(280, 302);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(222, 20);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(345, 205);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(85, 23);
            this.btnGuardar.TabIndex = 7;
            this.btnGuardar.Text = "button1";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(349, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "REGISTRARSE";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnNombre
            // 
            this.btnNombre.HideSelection = false;
            this.btnNombre.Location = new System.Drawing.Point(309, 93);
            this.btnNombre.Name = "btnNombre";
            this.btnNombre.Size = new System.Drawing.Size(71, 20);
            this.btnNombre.TabIndex = 0;
            this.btnNombre.Text = "Nombre";
            this.btnNombre.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // brnApellido
            // 
            this.brnApellido.Location = new System.Drawing.Point(400, 93);
            this.brnApellido.Name = "brnApellido";
            this.brnApellido.Size = new System.Drawing.Size(71, 20);
            this.brnApellido.TabIndex = 1;
            this.brnApellido.Text = "Apellido";
            this.brnApellido.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(236, 348);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(325, 23);
            this.progressBar1.Step = -9;
            this.progressBar1.TabIndex = 6;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // chkContraseña
            // 
            this.chkContraseña.AutoSize = true;
            this.chkContraseña.Location = new System.Drawing.Point(318, 182);
            this.chkContraseña.Name = "chkContraseña";
            this.chkContraseña.Size = new System.Drawing.Size(121, 17);
            this.chkContraseña.TabIndex = 4;
            this.chkContraseña.Text = "Guardar Contraseña";
            this.chkContraseña.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkContraseña.UseVisualStyleBackColor = true;
            this.chkContraseña.CheckedChanged += new System.EventHandler(this.chkContraseña_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 236);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Sexo";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(293, 119);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Direccion de correo electronico";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(293, 156);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(185, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Contraseña";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // froFemenino
            // 
            this.froFemenino.AutoSize = true;
            this.froFemenino.Location = new System.Drawing.Point(1, 19);
            this.froFemenino.Name = "froFemenino";
            this.froFemenino.Size = new System.Drawing.Size(71, 17);
            this.froFemenino.TabIndex = 10;
            this.froFemenino.TabStop = true;
            this.froFemenino.Text = "Femenino";
            this.froFemenino.UseVisualStyleBackColor = true;
            this.froFemenino.CheckedChanged += new System.EventHandler(this.froFemenino_CheckedChanged);
            // 
            // froMasculino
            // 
            this.froMasculino.AutoSize = true;
            this.froMasculino.Location = new System.Drawing.Point(78, 19);
            this.froMasculino.Name = "froMasculino";
            this.froMasculino.Size = new System.Drawing.Size(73, 17);
            this.froMasculino.TabIndex = 11;
            this.froMasculino.TabStop = true;
            this.froMasculino.Text = "Masculino";
            this.froMasculino.UseVisualStyleBackColor = true;
            // 
            // frbOtros
            // 
            this.frbOtros.AutoSize = true;
            this.frbOtros.Location = new System.Drawing.Point(150, 19);
            this.frbOtros.Name = "frbOtros";
            this.frbOtros.Size = new System.Drawing.Size(50, 17);
            this.frbOtros.TabIndex = 12;
            this.frbOtros.TabStop = true;
            this.frbOtros.Text = "Otros";
            this.frbOtros.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.froMasculino);
            this.groupBox1.Controls.Add(this.frbOtros);
            this.groupBox1.Controls.Add(this.froFemenino);
            this.groupBox1.Location = new System.Drawing.Point(292, 233);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 50);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkContraseña);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.brnApellido);
            this.Controls.Add(this.btnNombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.dateTimePicker1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox btnNombre;
        private System.Windows.Forms.TextBox brnApellido;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.CheckBox chkContraseña;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton froFemenino;
        private System.Windows.Forms.RadioButton froMasculino;
        private System.Windows.Forms.RadioButton frbOtros;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}


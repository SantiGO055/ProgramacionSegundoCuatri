﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
    class DirectorTecnico : Persona
    {
        int añosExperiencia;

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder(base.Mostrar());
            sb.AppendLine("Años de experiencia: ").Append(this.añosExperiencia) ;
            return sb.ToString;
        }
        

        public DirectorTecnico(string nombre,string apellido, int edad, int dni, int añosExperiencia)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.edad = edad;
            this.añosExperiencia = añosExperiencia;
        }
        public bool validarAptitud()
        {
            if (this.Edad <= 65 && this.AñosExperiencia >= 2)
            {
                return true;
            }
            else
                return false;
        }

        public int AñosExperiencia
        {
            get
            {
                return añosExperiencia;
            }
            set
            {
                this.añosExperiencia = value;
            }
        }
    }
}

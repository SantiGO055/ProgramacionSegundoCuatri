﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    abstract class Persona
    {
        string apellido;
        int dni;
        int edad;
        string nombre;

        public Persona(string nombre, string apellido, int edad, int dni)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.edad = edad;
        }
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }

        public int Dni
        {
            get
            {
                return this.dni;
            }
        }

        public int Edad
        {
            get
            {
                return this.edad;
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            return sb.AppendLine(apellido).Append(nombre).Append(edad).Append(dni);
        }


        public abstract bool ValidarAptitud();
        
    }
    


}
